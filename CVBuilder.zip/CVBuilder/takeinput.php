<?php
	session_start();
	
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>CV Builder</title>
	<style type='text/css'>
		
		
		
		.resume{
		font-size:40px;
		position:relative;
		top: 50px;
		}
		
		.group{
		font-size:20px;
		position:relative;
		top: 100px;
		}
		
		.next{
		font-size:20px;
		position:relative;
		top: 150px;
		}
	</style>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"> 
</head>
<body align="center">
<div class="color">
		
			<div class="resume">CREATE A CUSTOMIZED RESUME </div>
			<hr width="100%" style="display: block; border-color:white; border-style: inset; border-width: 1px; position:relative; top:25px;">
			<br>
			<div class="group">
			 Enter the number of Sections
			<form method="post" action="takeinput.php">
			<div class="container">
			<div class="row">
			<div class="col-md-offset-4 col-md-4">
				<div class="form-group">
					<input type="text" class="form-control" name="n" id="n" required> 
				</div>
			</div>
			</div>
			</div>
				<input class="btn btn-default" type="submit" name="submit" value="Submit" >
			</form>
			</div>
			
			
		<div class="next">	
			<form  method="post" action="takeinput1.php">
				<?php
				
				if(isset($_POST['submit'])){
				$n = $_POST['n'];
				$_SESSION['n'] = $n;
				echo "Enter the names of Sections <br>";
				for($i=0;$i<$n;$i++){ 
				?>
				<div class="container">
				<div class="row">
				<div class="col-md-offset-4 col-md-4">
					<input  class="form-control" type='text' id='section' name="<?php echo 'group'.$i; ?>" required> <br>
				</div>
				</div>
				</div>
				<?php
				}
				
					echo '<input class="btn btn-default" type="submit" name="submit" value="Submit">'; }?>
				
				
			</form>
		</div>
</div>	
</body>
</html>