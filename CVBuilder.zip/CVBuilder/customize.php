<?php
	session_start();
	$n = $_SESSION['n'] ;
	for($i=0;$i<$n;$i++){ 
		for($j=0;$j< $_SESSION['nof'.$i] ;$j++)
		{	
			$_SESSION['nof'.$i.$j] = $_POST['nof'.$i.$j];
		}
	}
	
?>

<html>
<head>
    <title>CV Builder</title>
    <link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"> 
	<style type='text/css'>
		body{
		background-color: #F9F9F9 ;
		}
		input[type=text] {
			padding: 12px 2px;
			box-sizing: border-box;
			border: 1px dotted;
			border-radius: 5px;
		}
		input[type=email] {
			padding: 12px 2px;
			box-sizing: border-box;
			border: 1px dotted;
			border-radius: 5px;
		}
		
		color:;
		}
		h1{
		font-size:50px;
		}
		
		
	</style>
</head>

<body>
    <center> <h1>CV BUILDER</h1> </center>
	<hr width="100%" style="display: block; border-color:white; border-style: inset; border-width: 1px;">
    <form method="post" action="cust_design1.php">
    <div class="container">
			<?php 
			for($i=0;$i<$n;$i++){ 
			?>	 <center> <h3 style="text-transform: uppercase;" ><label><?php echo $_SESSION['group'.$i]; ?></label><br> </h3> </center> <br>
        
			<?php
				for($j=0;$j< $_SESSION['nof'.$i] ;$j++)
				{
			?>
		
			<div class="row" style="text-transform: uppercase;">
				<div class="col-md-3">
					<label> <?php echo $_SESSION['nof'.$i.$j]; ?> </label> : 
				</div>
				<div class="col-md-3">
					<input type="text" name="<?php echo'fname'.$i.$j;?>" id="m" required><br>
				</div>
			</div> <br>
        
		<?php
			}
		} ?>
			
        
        <center> <input class="btn btn-default" type="submit" name="submit" value="Submit">
		</form> </center>
        
		
    </div>
    </form>
    
    
</body>
</html>
