<?php
	session_start();
	$n = $_SESSION['n'] ;
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>CV Builder</title>
	<style type='text/css'>
		h1{
		font-size:50px;
		}
		
		.resume{
		font-size:40px;
		position:relative;
		top: 50px;
		}
		
		.field{
		font-size:20px;
		position:relative;
		top: 100px;
		}
		
	</style>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"> 
</head>
<body>
	<div align="center">
	<div class="resume">CREATE A CUSTOMIZED RESUME </div>
	<hr width="100%" style="display: block; border-color:white; border-style: inset; border-width: 1px; position:relative; top:25px;">
		<div class="field">
			<form  method="post" action="takeinput2.php">
			<?php 
			for($i=0;$i<$n;$i++)
			{ 
			$_SESSION['group'.$i] = $_POST["group".$i]; //name of groups
			
			?>
				Enter the number of inputs in <?php echo $_POST['group'.$i]; ?><br>
				
				<div class="container">
				<div class="row">
				<div class="col-md-offset-4 col-md-4">
				<div class="form-group">
					<input class="form-control" type="text" name="<?php echo 'no_of_field'.$i; ?>" id="m" required><br><!-- no of fields in each group -->
				</div>
				</div>
				</div>
				</div>
			<?php
			
			}
			echo'<input class="btn btn-default" type="submit" name="submit" value="Submit">';
			echo '</form>';
			?>	
			
			
		</div>
	</div>
	
</body>
</html>