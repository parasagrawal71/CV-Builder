<?php
	session_start();
	$n = $_SESSION['n'] ;
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>CV Builder</title>
	<style type='text/css'>
		h1{
		font-size:50px;
		}
		
	</style>
</head>
<body>
	<div align="center">
		<div class="">
			
				
			
			<?php
			if(isset($_POST['submit']))
			{
			for($i=0;$i<$n;$i++)
			{
				echo $_SESSION['field'.$i]; echo'<br>';
				for($j=0;$j<$_POST['entry'.$i];$j++) {
				$_SESSION['column'.$j] = $_POST['column'.$j];
				echo $_SESSION['column'.$j]; 	?>
				<form method="post" action=".php">
					<input type="text" name="" id="section" required> <br>
						<?php

			} }?>
					
					<input type="submit" value="Submit">
				</form>
			<?php
			} ?>
		</div>
	</div>
	
</body>
</html>