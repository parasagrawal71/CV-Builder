<?php
//personal
    $name=$_POST['name'];
	$usn=$_POST['usn'];
	$branch=$_POST['branch'];
	$gender=$_POST['gender'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    
    $dob=$_POST['dob'];
	
	
    $address1=$_POST['address1'];
	$address2=$_POST['address2'];
    
//QUALIFICATION
	$university1=$_POST['university1'];
	$institute1=$_POST['institute1'];
	$year1=$_POST['year1'];
	$university2=$_POST['university2'];
	$institute2=$_POST['institute2'];
	$year2=$_POST['year2'];
	$university3=$_POST['university3'];
	$institute3=$_POST['institute3'];
	$year3=$_POST['year3'];
    $matric=$_POST['matric'];
    $pu=$_POST['pu'];
    $cgpa=$_POST['cgpa'];

 //Skills
	$plang=$_POST['plang'];
    $lang=$_POST['lang']; 
	
//Achievements
    $scholar=$_POST['scholar'];
    $paper=$_POST['paper'];
    $research=$_POST['research'];

 //Work Experience
    $comp=$_POST['comp'];
    $dest=$_POST['dest'];
    $year=$_POST['year'];

//Extra	
    $sport=$_POST['sport'];
    $club=$_POST['club'];
    $vol=$_POST['vol'];

//Design
	$design=$_POST['design'];
    
$db = mysqli_connect('localhost','root','','cvbuilder');

				
	
		$sql="SHOW TRIGGERS;";
		if(mysqli_query($db,$sql)){
		$sql1="CREATE TRIGGER MyTrigger AFTER INSERT ON education FOR EACH ROW BEGIN 
		
		IF NEW.pu>90 THEN
		INSERT INTO status(CATEGORY) VALUES('OUTSTANDING');
		
		ELSEIF NEW.pu<91 THEN
			IF NEW.pu>70 THEN
			INSERT INTO status(CATEGORY) VALUES('GOOD');
			END IF;
								
		END IF;
		END;";
		mysqli_query($db,$sql1); 
		}
	
     $query1 =" INSERT INTO personal(name,usn,branch,gender,email,phone,dob,address1,address2) VALUES
            ('$name','$usn','$branch','$gender','$email','$phone','$dob','$address1','$address2')";
	$query2 = "INSERT INTO education(university1,university2,university3,institute1,institute2,institute3,year1,year2,year3,matric,pu,cgpa) VALUES
            ('$university1','$university2','$university3','$institute1','$institute2','$institute3','$year1','$year2','$year3','$matric','$pu','$cgpa' )";
	$query3 = "INSERT INTO achievement(scholar,paper,research) VALUES
            ('$scholar' ,'$paper','$research')";
	$query4 = "INSERT INTO skills(plang,lang) VALUES
            ('$plang','$lang')";
	$query5 = "INSERT INTO experience(comp,dest,year) VALUES
            ('$comp', '$dest' , '$year' )";
	$query6 = "INSERT INTO extra(sport,club,vol) VALUES
            ('$sport', '$club','$vol')";
    if((mysqli_query($db,$query1))&&(mysqli_query($db,$query2))&&(mysqli_query($db,$query3))&&(mysqli_query($db,$query4))&&(mysqli_query($db,$query5))&&(mysqli_query($db,$query6)))
    {	
		if($design=="design1"){
			echo "<SCRIPT type='text/javascript'>
					alert('Successful');
											
					window.location.replace('design1.php');
					</SCRIPT>" ; ;
		}
		 else if($design=="design2"){
			echo "<SCRIPT type='text/javascript'>
					alert('Successful');
											
					window.location.replace('design2.php');
					</SCRIPT>" ;
		}
	}
    else{
        echo "Unsuccessful";
    }
?>