<?php
session_start();
if(isset($_POST['submit'])) {
	$tablename=$_SESSION['tablename'];
	$colname=$_POST['subsec'];
	$old=$_POST['ovalue'];
	$new=$_POST['nvalue'];
	
	

	$db=mysqli_connect('localhost','root','','cvbuilder');
	
					$query1 = "SELECT MAX(id) FROM $tablename ";
					$res = mysqli_query($db,$query1);
					$id = 0;
		
					while($row = mysqli_fetch_array($res))
					$id = $row[0];
				
		
		
	$query=" UPDATE $tablename SET $colname='$new' WHERE $colname='$old' AND id='$id' ";
	
	
	if(mysqli_query($db,$query)){
		echo "<SCRIPT type='text/javascript'>
					alert('UPDATED Successfully');
											
					window.location.replace('design1.php');
					</SCRIPT>" ;
	}
	else {
		echo "<SCRIPT type='text/javascript'>
					alert('Enter details properly');
											
					window.location.replace('update1.php');
					</SCRIPT>" ;
	}
}



?>

<html>
<head>
	<title>CV Builder</title>
	<style type='text/css'>
		
		
		
		.resume{
		font-size:40px;
		position:relative;
		top: 50px;
		}
		
		.group{
		font-size:20px;
		position:relative;
		top: 100px;
		}
		
		.next{
		font-size:20px;
		position:relative;
		top: 150px;
		}
	</style>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"> 
</head>


<body>
<body align="center">

		
			<div class="resume"> UPDATE YOUR RESUME </div>
			<hr width="100%" style="display: block; border-color:white; border-style: inset; border-width: 1px; position:relative; top:25px;">
			<br>
			<div class="group">
			 Enter the details to be updated <br> <br>
			 
			<div class="container">
			<div class="row">
			<div class="col-md-offset-4 col-md-4">
			
			<form method="post" action="update1.php">
				<div class="form-group">
					Enter the name of Section
					<input type="text" class="form-control" name="section" id="section" required> 
				</div>
				<input class="btn btn-default" type="submit" name="show" value="Submit" >
			
			<?php
			if(isset($_POST['show'])){
					$tablename=$_POST['section'];
					$_SESSION['tablename']= $tablename;
				
					$db=mysqli_connect('localhost','root','','cvbuilder');
					$query=" DESC $tablename ";
					if($res = mysqli_query($db,$query)){
						echo '<br>'; echo "Select the Column Name";
					while($row = mysqli_fetch_array($res)){
						if($row[0]!='id'){
						echo'<br>'; echo $row['0'];
						}
						}
					}
				}
			?>
			</form>		
			<form method="post" action="update1.php">
				<div class="form-group">
					Enter the name of Column
					<input type="text" class="form-control" name="subsec" id="subsec" required> 
				</div>
				<div class="form-group">
					Enter the older value
					<input type="text" class="form-control" name="ovalue" id="ovalue" required> 
				</div>
				<div class="form-group">
					Enter the new value
					<input type="text" class="form-control" name="nvalue" id="nvalue" required> 
				</div>
			</div>
			</div>
			</div>
				<input class="btn btn-default" type="submit" name="submit" value="Submit" >
			</form>
			</div>
			
</body>


</body>
</html>