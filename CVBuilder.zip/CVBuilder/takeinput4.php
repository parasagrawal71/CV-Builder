<?php
session_start();
$n = $_SESSION['n'] ;
?>
<!DOCTYPE html>
<html>
<head>
	<title>CV Builder</title>
	<style type='text/css'>
		h1{
		font-size:50px;
		}
		
	</style>
</head>
<body>
	<div align="center">
		<div class="">

		</div>
	</div>
	<?php
		for($i=0;$i< $n;$i++)
		{
			for($j=0;$j< $_SESSION['nof'.$i] ;$j++)
			{
				echo $_SESSION['nof'.$i.$j].' : '.$_POST['fname'.$i.$j].'<br>';
			}
		}
		
	?>
</body>
</html>