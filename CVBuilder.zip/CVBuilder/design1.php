<!DOCTYPE HTML>
<html lang="mul" dir="ltr">
<head>
	<title></title>
	<meta charset="utf-8">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<style type="text/css">
		
		
		
		table,th,td,tr{
			border: 1px solid black; 
			padding : 10px ; 
			text-align: left; 
		}
	</style>
</head>

<body>
	<div id="HTMLtoPDF">
		<div class="top">
			<div class="container">
				<div class="row">
				
				<?php
				
					$db=mysqli_connect('localhost','root','','cvbuilder');
					$query = "SELECT MAX(id) FROM personal";
					$res = mysqli_query($db,$query);
					$id = 0;
		
					while($row = mysqli_fetch_array($res))
					$id = $row[0];
				
					$query="SELECT * FROM personal,achievement,education,experience,extra,skills 
					WHERE personal.id='$id' AND achievement.id='$id' AND education.id = '$id' 
					AND experience.id = '$id' AND extra.id='$id' AND skills.id= '$id' ";
					$res = mysqli_query($db,$query);				
					while($row = mysqli_fetch_array($res))
						{ ?>
						
					<div class="col-md-9">
						<div class="hori_line1">
							<hr width="75%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
						</div>
						
						<div class="name">
						<h2> <?php echo $row['name']; ?> </h2>
						<h4> Sir M. Visvesvaraya Institute of Technology </h4>
						</div>
						
						<div class="hori_line2">
							<hr width="75%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
						</div>
					</div>
					
					<div class="col-md-3">
						<div class="logo">
							<img src="img/logo.jpg">
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-md-offset-1">
					<?php echo $row['branch']; ?><br>
					<?php echo $row['usn']; ?><br>
					<?php echo $row['gender']; ?><br>
					<?php echo $row['dob']; ?><br>
					</div>	
					
					<div class="col-md-offset-1 col-md-3">
					<?php echo $row['email']; ?><br>
					<?php echo $row['phone']; ?><br>
					<?php echo $row['address1']; ?>
					<?php echo $row['address2']; ?><br><br>
					</div>
					
				</div>
			</div>
		
			<div class="container">
				<div class="row">
					<div class="col-md-2">
					EDUCATION
					<hr width="100%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
					</div>
					
					<div class="col-md-offset-1 col-md-9">
						<table border="1">
							<tr> 
								<th>Examination</th> 
								<th>University</th>
								<th>Institute</th>
								<th>Year</th>
								<th>%/CGPA</th>
							</tr>
							<tr>
								<td>MATRIC</td>
								<td><?php echo $row['university1']; ?></td>
								<td><?php echo $row['institute1']; ?></td>
								<td><?php echo $row['year1']; ?></td>
								<td><?php echo $row['matric']; ?></td>
							</tr>
							<tr>
								<td>PU</td>
								<td><?php echo $row['university2']; ?></td>
								<td><?php echo $row['institute2']; ?></td>
								<td><?php echo $row['year2']; ?></td>
								<td><?php echo $row['pu']; ?></td>
							</tr>
							<tr>
								<td>College</td>
								<td><?php echo $row['university3']; ?></td>
								<td><?php echo $row['institute3']; ?></td>
								<td><?php echo $row['year3']; ?></td>
								<td><?php echo $row['cgpa']; ?></td>
							</tr>
						</table> <br><br>
					</div>
				</div>
			</div>
		
			<div class="container">
				<div class="row">
					<div class="col-md-2">
					SKILLS
					<hr width="100%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
					</div>
					
					<div class="col-md-offset-1 col-md-9">
							<table border="1">
							<tr> 
								<th>PROGRAMMING LANGUAGES:-</th> 
								<th>LANGUAGES:-</th>
								
							</tr>
							<tr>
								<td><?php echo $row['plang']; ?></td>
								<td><?php echo $row['lang']; ?> </td>
								
							</tr>
														
						</table> <br><br>
					</div>
				</div>
			</div>
		
			<div class="container">
				<div class="row">
					<div class="col-md-2">
					ACHIEVEMENT
					<hr width="100%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
					</div>
					
					<div class="col-md-offset-1 col-md-9">
						<table border="1">
							<tr> 
								<th>SCHOLARSHIP:-</th> 
								<th>PAPER PRESENTATION:-</th>
								<th>RESEARCH:-</th>
								
							</tr>
							<tr>
								<td><?php echo $row['scholar']; ?></td>
								<td><?php echo $row['paper']; ?> </td>
								<td><?php echo $row['research']; ?> </td>
								
							</tr>
														
						</table> <br><br>
					</div>
				</div>
			</div>
		
			<div class="container">
				<div class="row">
					<div class="col-md-2">
					WORK EXPERIENCE:-
					<hr width="100%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
					</div>
					
					<div class="col-md-offset-1 col-md-9">	
						<table border="1">
							<tr> 
								<th>COMPANY NAME:-</th> 
								<th>DESIGNATION:-</th>
								<th>EXPERIENCE:-</th>
								
							</tr>
							<tr>
								<td><?php echo $row['comp']; ?></td>
								<td><?php echo $row['dest']; ?> </td>
								<td><?php echo $row['year']; ?> </td>
								
							</tr>
														
						</table> <br><br>
					</div>
				</div>
			</div>
		
			<div class="container">
				<div class="row">
					<div class="col-md-2">
					EXTRA CIRRICULAR ACTIVITIES
					<hr width="100%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
					</div>
					
					<div class="col-md-offset-1 col-md-9">
						<table border="1">
							<tr> 
								<th>SPORTS:-</th> 
								<th>CLUB MEMBERSHIP:-</th>
								<th>VOLUNTEER EXPERIENCE:-</th>
								
							</tr>
							<tr>
								<td><?php echo $row['sport']; ?></td>
								<td><?php echo $row['club']; ?> </td>
								<td><?php echo $row['vol']; ?> </td>
								
							</tr>
														
						</table> <br><br>
					</div>
				</div>
			</div>
		
	</div>
	
	<div align="center">
	<div class="col-md-3 col-md-offset-5">
		<input type="submit" value="DOWNLOAD PDF" name="pdf" id="pdf" onclick="HTMLtoPDF()" class="form-control" style="background-color: #80ff80; font-weight: 1000;"> <br>
		<form action="update1.php" method="post">
			<input type="submit" value="UPDATE" name="" id="" class="form-control" style="background-color: #80ff80; font-weight: 1000;" >  <br>
		</form>
	</div>
	</div> 
	<?php
	break;
	}
	?>
	
	<!-- <input type="submit" value="DOWNLOAD PDF" name="pdf" id="pdf" onclick="HTMLtoPDF()">          
	<input type="submit" value="DOWNLOAD PDF" name="pdf" id="pdf" onclick="window.print()" target="_blank" style="cursor:pointer;">
	 -->
	<script src="js/pdfFromHTML.js"></script>
	<script src="js/jquery-2.1.3.js"></script>
	<script src="js/jspdf.js"></script>
	
</body>
</html>

