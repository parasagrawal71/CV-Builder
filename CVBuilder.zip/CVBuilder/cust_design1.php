<!DOCTYPE HTML>
<html lang="mul" dir="ltr">
<head>
	<title></title>
	<meta charset="utf-8">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<style type="text/css">
		
		
		
		table,th,td,tr{
			border: 1px solid black; 
			padding : 10px ; 
			text-align: left; 
		}
	</style>
</head>

<body>
	<div id="HTMLtoPDF">
		<div class="top">
			<div class="container">
				<div class="row">
				
				<?php
				
					session_start();
					$n = $_SESSION['n'] ;
		
				
					?>
						
					<div class="col-md-9">
						<div class="hori_line1">
							<hr width="75%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
						</div>
						
						<div class="name">
						<h2> <?php echo $_POST['fname'.'0'.'0']; ?> </h2>
						<h4> Sir M. Visvesvaraya Institute of Technology </h4>
						</div>
						
						<div class="hori_line2">
							<hr width="75%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
						</div>
					</div>
					
					<div class="col-md-3">
						<div class="logo">
							<img src="img/logo.jpg">
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<?php
		for($i=0;$i< $n;$i++){
		?>
		
			<div class="container">
				<div class="row">
					<div class="col-md-2" style="text-transform: uppercase; font-size:15px;">
					<?php echo $_SESSION["group".$i]; ?>
					<hr width="100%" style="display: block; border-color:black; border-style: inset; border-width: 1px;">
					</div>
				</div>	
					
					
					<div class="row">
						<?php 	
							
								for($j=0;$j< $_SESSION['nof'.$i] ;$j++)
								{ ?>					
								
									<div class="col-md-10 col-md-offset-2" style="text-transform: uppercase;">
								 <?php  
										echo $_SESSION['nof'.$i.$j]. ':' ;
										 
										echo $_POST['fname'.$i.$j].'<br>';?> 
									</div>
								
							
						<?php 
								}
							
						
		}?>				
						</table> <br><br>
					</div>
				</div>
			</div>
		
	<div class="col-md-3 col-md-offset-5">		
	<div align="center">
		<input type="submit" value="DOWNLOAD PDF" name="pdf" id="pdf" onclick="HTMLtoPDF()" class="form-control" style="background-color: #80ff80; font-weight: 1000;" > 
	</div>	
    </div> 
	
	
	<!-- <input type="submit" value="DOWNLOAD PDF" name="pdf" id="pdf" onclick="HTMLtoPDF()"> 
	<input type="submit" value="DOWNLOAD PDF" name="pdf" id="pdf" onclick="window.print()" target="_blank" style="cursor:pointer;">
	 -->
	<script src="js/pdfFromHTML.js"></script>
	<script src="js/jquery-2.1.3.js"></script>
	<script src="js/jspdf.js"></script>
	
</body>
</html>

