window.print();
console.log("Hello");